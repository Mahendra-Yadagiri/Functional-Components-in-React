
import './App.css';
import CricketPlayer from './components/CricketPlayer';

function App() {
  return (
    
 <div>
  <h1> Friendly Laptop Store </h1>
  
   
    <div className="App">
      <h2>Without components</h2>
      <div className='playerContainer' >
        <img src='./images/mac1.jpeg' alt=''></img>
        <div className="laptops">
          <h3>Name/Brand - Apple</h3>
          <h4>Model - MacBook Air (M2)</h4>
          <h4>Display - (13.6 inches) with Retina Display </h4>
          <h4>Price - 114999/-</h4>
          <select>
           
            <optgroup>
              <option>Ram-4GB</option>
              <option>Ram-8GB</option>
              <option>Ram-16GB</option>
              <option>Ram-32GB</option>
                <option>SSD-512GB</option>
                <option>SSD-1TB</option>
                 <option>SSD-2TB</option>
                 <option>SSD-3TB</option>
            </optgroup>
          </select>
          <p><b>Feature-</b>Apple laptops are known for their premium build quality, sleek design, and smooth performance. They offer excellent battery life, high-resolution Retina displays, and seamless integration with the Apple ecosystem.</p>
       
      </div>
      </div>
      

      <div className='playerContainer'>
        <img src='./images/linux.jpeg' alt=''></img>
        <div className="laptops">
        <h3>Name/Brand-Dell</h3>
          <h4>Model-Dell XPS 13 Developer Edition</h4>
          <h4>Display-13.4-inch FHD+ / UHD+ </h4>
          <h4>Price-₹1,09,999/- (approx)</h4>
          <select>
           
            <optgroup>
              <option>Ram-4GB</option>
              <option>Ram-8GB</option>
              <option>Ram-16GB</option>
                <option>SSD-512GB</option>
            </optgroup>
          </select>
          <p><b>Feature-</b>Preloaded with Ubuntu Linux, lightweight design, strong performance, excellent for developers and professionals.</p>
          </div>
      </div>

      <div className='playerContainer'>
        <img src='./images/lap1.jpeg' alt=''></img>
        <div className="laptops">
        <h3>Name/Brand-HP</h3>
          <h4>Model – HP Pavilion 14</h4>
          <h4>Display – 14-inch FHD</h4>
          <h4>Price – ₹58,999/- (approx)</h4>
          <select>
           
            <optgroup>
              <option>Ram-4GB</option>
              <option>Ram-8GB</option>
              <option>Ram-16GB</option>
                <option>SSD-512GB</option>
            </optgroup>
          </select>
          <p><b>Feature-</b>Sleek design, lightweight, strong performance for students and professionals, runs Windows 11.</p>
          </div>
      
      </div>
      <br></br>
      <h2>With components </h2>
      <br></br>
      
      <div>
    <CricketPlayer name="ACER" model="Aspire 7" display="15.6 Full HD IPS" imgURL="./images/acer.jpeg" price="₹52,990 (approx.)" feature="Acer laptops are known for their strong performance at affordable prices.
They feature sleek designs, good battery life, and vibrant displays.
With models for students, professionals, and gamers, Acer offers a wide variety to suit different needs."></CricketPlayer>
      <CricketPlayer name="ASUS" model="Vivobook 15" display="15.6 Full HD (1920 × 1080)" imgURL="./images/asus.jpeg" price="₹45,999 (approx.)" feature="ASUS laptops are popular for their stylish design, strong performance, and affordability.
They have a wide range, from everyday use laptops to high-end gaming and creator series.
With great displays and powerful hardware, ASUS laptops are trusted by students and professionals alike."></CricketPlayer>
      <CricketPlayer name="LENOVO" model="IdeaPad Slim 5" display="15.6 Full HD IPS" price="₹58,999 (approx.)" imgURL="./images/lenovo.jpeg" feature="Lenovo laptops are known for their durability, sleek designs, and powerful performance.
They offer a wide range of models, from budget-friendly options to high-end business and gaming laptops. "></CricketPlayer>
</div>
</div>


   
    
    </div>
  );
}

export default App;
