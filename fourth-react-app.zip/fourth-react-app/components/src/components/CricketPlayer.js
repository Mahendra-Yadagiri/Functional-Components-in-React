import React from 'react';
import '../App.css';



function CricketPlayer(props) {
  return (
    
    
    <div className='playerContainer'>
      
        <img src={props.imgURL} alt=''></img>
        <div className='laptops'>
        <h3>Name/Brand-{props.name}</h3>
        <h4>Model-{props.model}</h4>
        <h4>Display-{props.display}</h4>
        <h4>Price-{props.price}</h4>
        <select>
           
            <optgroup>
              <option>Ram-4GB</option>
              <option>Ram-8GB</option>
              <option>Ram-16GB</option>
                <option>SSD-512GB</option>
            </optgroup>
          </select>
        <p><b>Feature:</b>{props.feature}</p>
        </div>
      
     
      </div>
     
  )
}

export default CricketPlayer
